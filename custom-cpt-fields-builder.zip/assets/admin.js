jQuery(document).ready(function ($) {
    // Color picker init
    $('.cpt-builder-color').wpColorPicker();

    // Media uploader for file fields
    var mediaUploader;
    $('.cpt-builder-upload-btn').click(function (e) {
        e.preventDefault();
        var button = $(this);
        var input = button.prev('input');

        if (mediaUploader) {
            mediaUploader.open();
            return;
        }

        mediaUploader = wp.media({
            title: 'Choose File',
            button: { text: 'Select File' },
            multiple: false
        });

        mediaUploader.on('select', function () {
            var attachment = mediaUploader.state().get('selection').first().toJSON();
            input.val(attachment.id);
            button.next('.file-preview').html('<a href="' + attachment.url + '" target="_blank">View File</a>');
        });

        mediaUploader.open();
    });

    // Show/hide relationship target selector
    $('#field_type').change(function () {
        if ($(this).val() === 'relationship') {
            $('#relationship_target_row').show();
        } else {
            $('#relationship_target_row').hide();
        }
    }).trigger('change');
});
