<?php
/*
Plugin Name: Custom CPT & Fields Builder
Description: Toolset-like plugin to create custom post types, taxonomies, and fields with media & color support.
Version: 1.5
Author: Sumit Kumar
*/

if (!defined('ABSPATH')) exit;

// Enqueue admin scripts and styles only on plugin page
add_action('admin_enqueue_scripts', function ($hook) {
    if ($hook !== 'toplevel_page_cpt-builder') return;
    wp_enqueue_style('wp-color-picker');
    wp_enqueue_style('cpt-builder-admin-css', plugin_dir_url(__FILE__) . 'assets/admin.css');
    wp_enqueue_script('cpt-builder-admin-js', plugin_dir_url(__FILE__) . 'assets/admin.js', ['jquery', 'wp-color-picker'], '1.0', true);
});

// Add plugin admin menu page
add_action('admin_menu', function () {
    add_menu_page('CPT Builder', 'CPT Builder', 'manage_options', 'cpt-builder', 'cpt_builder_admin_page');
});

// Admin page HTML + forms
function cpt_builder_admin_page() {
    $cpts = get_option('custom_cpts', []);
    $taxonomies = get_option('custom_taxonomies', []);
    ?>
    <div class="wrap">
        <h1>Custom Post Type & Field Builder</h1>

        <!-- Create CPT -->
        <h2>Create Custom Post Type</h2>
        <form method="post">
            <?php wp_nonce_field('create_cpt_action', 'create_cpt_nonce'); ?>
            <table class="form-table">
                <tr><th><label for="cpt_slug">Post Type Slug</label></th><td><input type="text" id="cpt_slug" name="cpt_slug" required></td></tr>
                <tr><th><label for="cpt_name">Singular Name</label></th><td><input type="text" id="cpt_name" name="cpt_name" required></td></tr>
            </table>
            <p><input type="submit" name="create_cpt" class="button button-primary" value="Create CPT"></p>
        </form>

        <?php if (!empty($cpts)): ?>
        <h2>Existing Custom Post Types</h2>
        <ul>
            <?php foreach ($cpts as $slug => $name): ?>
                <li><strong><?php echo esc_html($slug); ?>:</strong> <?php echo esc_html($name); ?></li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>

        <hr>

        <!-- Add Custom Field -->
        <h2>Add Custom Field</h2>
        <form method="post">
            <?php wp_nonce_field('add_field_action', 'add_field_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="field_post_type">Post Type</label></th>
                    <td>
                        <select name="field_post_type" id="field_post_type" required>
                            <option value="">Select</option>
                            <?php foreach ($cpts as $slug => $name): ?>
                                <option value="<?php echo esc_attr($slug); ?>"><?php echo esc_html($name); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
                <tr><th><label for="field_key">Field Key</label></th><td><input type="text" name="field_key" required></td></tr>
                <tr><th><label for="field_label">Field Label</label></th><td><input type="text" name="field_label" required></td></tr>
                <tr>
                    <th><label for="field_type">Field Type</label></th>
                    <td>
                        <select name="field_type" id="field_type">
                            <option value="text">Text</option>
                            <option value="textarea">Textarea</option>
                            <option value="number">Number</option>
                            <option value="relationship">Relationship</option>
                            <option value="color">Color Picker</option>
                            <option value="file">File Upload</option>
                        </select>
                    </td>
                </tr>
                <tr id="relationship_target_row" style="display: none;">
                    <th><label for="relationship_target">Target Post Type</label></th>
                    <td>
                        <select name="relationship_target">
                            <option value="">Select Target Post Type</option>
                            <?php foreach ($cpts as $slug => $name): ?>
                                <option value="<?php echo esc_attr($slug); ?>"><?php echo esc_html($name); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
                <tr><th><label>Visible to Roles</label></th>
                    <td>
                        <?php foreach (wp_roles()->roles as $role_key => $role): ?>
                            <label><input type="checkbox" name="field_roles[]" value="<?php echo esc_attr($role_key); ?>"> <?php echo esc_html($role['name']); ?></label><br>
                        <?php endforeach; ?>
                    </td>
                </tr>
            </table>
            <p><input type="submit" name="add_field" class="button button-primary" value="Add Field"></p>
        </form>

        <hr>

        <!-- Add Taxonomy -->
        <h2>Create Custom Taxonomy</h2>
        <form method="post">
            <?php wp_nonce_field('add_taxonomy_action', 'add_taxonomy_nonce'); ?>
            <table class="form-table">
                <tr><th><label for="taxonomy_slug">Taxonomy Slug</label></th><td><input type="text" name="taxonomy_slug" required></td></tr>
                <tr><th><label for="taxonomy_label">Taxonomy Label</label></th><td><input type="text" name="taxonomy_label" required></td></tr>
                <tr>
                    <th><label for="taxonomy_post_type">Attach to Post Type</label></th>
                    <td>
                        <select name="taxonomy_post_type" required>
                            <option value="">Select</option>
                            <?php foreach ($cpts as $slug => $name): ?>
                                <option value="<?php echo esc_attr($slug); ?>"><?php echo esc_html($name); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
            </table>
            <p><input type="submit" name="add_taxonomy" class="button button-primary" value="Add Taxonomy"></p>
        </form>

        <script>
            document.getElementById('field_type').addEventListener('change', function () {
                document.getElementById('relationship_target_row').style.display = this.value === 'relationship' ? 'table-row' : 'none';
            });
        </script>
    </div>
    <?php
}

// Handle form submissions securely
add_action('admin_init', function () {
    if (isset($_POST['create_cpt']) && check_admin_referer('create_cpt_action', 'create_cpt_nonce')) {
        $slug = sanitize_key($_POST['cpt_slug']);
        $name = sanitize_text_field($_POST['cpt_name']);
        $cpts = get_option('custom_cpts', []);
        $cpts[$slug] = $name;
        update_option('custom_cpts', $cpts);
    }

    if (isset($_POST['add_field']) && check_admin_referer('add_field_action', 'add_field_nonce')) {
        $post_type = sanitize_key($_POST['field_post_type']);
        $key = sanitize_key($_POST['field_key']);
        $label = sanitize_text_field($_POST['field_label']);
        $type = sanitize_text_field($_POST['field_type']);
        $roles = array_map('sanitize_text_field', $_POST['field_roles'] ?? []);
        $relationship_target = sanitize_key($_POST['relationship_target'] ?? '');

        $fields = get_option("fields_$post_type", []);
        $fields[$key] = [
            'label' => $label,
            'type' => $type,
            'roles' => $roles,
            'relationship_target' => $relationship_target,
        ];
        update_option("fields_$post_type", $fields);
    }

    if (isset($_POST['add_taxonomy']) && check_admin_referer('add_taxonomy_action', 'add_taxonomy_nonce')) {
        $slug = sanitize_key($_POST['taxonomy_slug']);
        $label = sanitize_text_field($_POST['taxonomy_label']);
        $post_type = sanitize_key($_POST['taxonomy_post_type']);

        $taxonomies = get_option('custom_taxonomies', []);
        $taxonomies[$slug] = ['label' => $label, 'post_type' => $post_type];
        update_option('custom_taxonomies', $taxonomies);
    }
});

// Register CPTs on init
add_action('init', function () {
    $cpts = get_option('custom_cpts', []);
    foreach ($cpts as $slug => $name) {
        register_post_type($slug, [
            'label' => $name,
            'public' => true,
            'has_archive' => true,
            'show_in_menu' => true,
            'supports' => ['title', 'editor', 'thumbnail'],
        ]);
    }
});

// Register taxonomies on init
add_action('init', function () {
    $taxonomies = get_option('custom_taxonomies', []);
    foreach ($taxonomies as $slug => $args) {
        register_taxonomy($slug, $args['post_type'], [
            'label' => $args['label'],
            'public' => true,
            'hierarchical' => true,
            'show_ui' => true,
            'show_admin_column' => true,
            'rewrite' => ['slug' => $slug],
        ]);
    }
});

// Add meta boxes for custom fields
add_action('add_meta_boxes', function () {
    global $post;
    if (!isset($post)) return;
    $fields = get_option("fields_{$post->post_type}", []);
    if (!$fields) return;

    add_meta_box('custom_fields_box', 'Custom Fields', function () use ($fields, $post) {
        $user = wp_get_current_user();
        wp_nonce_field('save_cpt_fields', 'cpt_fields_nonce');
        foreach ($fields as $key => $data) {
            if (!empty($data['roles']) && !array_intersect($data['roles'], $user->roles)) continue;

            $value = get_post_meta($post->ID, $key, true);
            echo '<p><label><strong>' . esc_html($data['label']) . '</strong></label><br>';
            switch ($data['type']) {
                case 'textarea':
                    echo '<textarea style="width:100%" name="' . esc_attr($key) . '">' . esc_textarea($value) . '</textarea>';
                    break;
                case 'number':
                    echo '<input type="number" name="' . esc_attr($key) . '" value="' . esc_attr($value) . '" style="width:100%">';
                    break;
                case 'relationship':
                    $target = $data['relationship_target'];
                    $posts = get_posts(['post_type' => $target, 'numberposts' => -1]);
                    echo '<select name="' . esc_attr($key) . '" style="width:100%">';
                    echo '<option value="">Select ' . esc_html($target) . '</option>';
                    foreach ($posts as $p) {
                        printf(
                            '<option value="%s" %s>%s</option>',
                            esc_attr($p->ID),
                            selected($value, $p->ID, false),
                            esc_html($p->post_title)
                        );
                    }
                    echo '</select>';
                    break;
                case 'color':
                    echo '<input class="cpt-builder-color" type="text" name="' . esc_attr($key) . '" value="' . esc_attr($value) . '" style="width:100%">';
                    break;
                case 'file':
                    echo '<input type="hidden" name="' . esc_attr($key) . '" value="' . esc_attr($value) . '">';
                    echo '<button class="cpt-builder-upload-btn button">Upload/Select File</button> ';
                    if ($value) {
                        $url = wp_get_attachment_url($value);
                        if ($url) echo '<span class="file-preview"><a href="' . esc_url($url) . '" target="_blank">View File</a></span>';
                    } else {
                        echo '<span class="file-preview"></span>';
                    }
                    break;
                case 'text':
                default:
                    echo '<input type="text" name="' . esc_attr($key) . '" value="' . esc_attr($value) . '" style="width:100%">';
            }
            echo '</p>';
        }
    }, null, 'advanced', 'high');
});

// Save meta box data
add_action('save_post', function ($post_id) {
    if (!isset($_POST['cpt_fields_nonce']) || !wp_verify_nonce($_POST['cpt_fields_nonce'], 'save_cpt_fields')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;

    $post_type = get_post_type($post_id);
    $fields = get_option("fields_$post_type", []);
    if (!$fields) return;

    foreach ($fields as $key => $data) {
        if (isset($_POST[$key])) {
            $val = sanitize_text_field($_POST[$key]);
            if ($data['type'] === 'file') {
                // File id stored as integer
                $val = intval($val);
            }
            update_post_meta($post_id, $key, $val);
        }
    }
});

// Shortcode to display custom fields by post id: [show_cpt_fields post_id=123]
add_shortcode('show_cpt_fields', function ($atts) {
    $atts = shortcode_atts(['post_id' => 0], $atts, 'show_cpt_fields');
    $post_id = intval($atts['post_id']);
    if (!$post_id) return 'Invalid post ID';

    $post_type = get_post_type($post_id);
    $fields = get_option("fields_$post_type", []);
    if (!$fields) return 'No custom fields found';

    $output = '<div class="cpt-fields-display">';
    foreach ($fields as $key => $data) {
        $val = get_post_meta($post_id, $key, true);
        if (!$val) continue;

        $label = esc_html($data['label']);
        switch ($data['type']) {
            case 'color':
                $output .= "<p><strong>{$label}:</strong> <span style='display:inline-block;width:20px;height:20px;background:{$val};border:1px solid #000;'></span></p>";
                break;
            case 'file':
                $url = wp_get_attachment_url($val);
                if ($url) {
                    $output .= "<p><strong>{$label}:</strong> <a href='{$url}' target='_blank'>Download File</a></p>";
                }
                break;
            case 'relationship':
                $rel_post = get_post($val);
                if ($rel_post) {
                    $output .= "<p><strong>{$label}:</strong> " . esc_html($rel_post->post_title) . "</p>";
                }
                break;
            default:
                $output .= "<p><strong>{$label}:</strong> " . esc_html($val) . "</p>";
        }
    }
    $output .= '</div>';
    return $output;
});
